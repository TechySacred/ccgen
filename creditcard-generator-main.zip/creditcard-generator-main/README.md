# creditcard-generator
A simple cc generator using bin Ex. 5114320921xxxxxx (This is an example and not working bin) built using pure javasciprt, css and html.
